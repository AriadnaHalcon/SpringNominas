package com.app.SpringNominas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringNominasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringNominasApplication.class, args);
	}

}
